#ifndef PARSED_DATA_H
#define PARSED_DATA_H

// any source file that includes this will be able to use "global_x"
extern signed short target_x;
extern signed short target_y;

extern signed short rover_x;
extern signed short rover_y;
extern signed short rover_angle;

#endif